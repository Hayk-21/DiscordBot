roles = [
    'admin',
    'struk',
    'асд',
    'асдя"яш',
]

channels = [
    'bot-area',
    'private',
    'general',
    'асшсс',
]

